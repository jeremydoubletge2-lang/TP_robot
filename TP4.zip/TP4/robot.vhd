library ieee;
use ieee.std_logic_1164.all;

entity robot is
port (
    SW : in std_logic_vector(3 downto 0);
    KEY : in std_logic_vector(0 downto 0);
    CLOCK_50 : in std_logic;
    LED : out std_logic_vector(3 downto 0);

    -- SDRAM
    DRAM_CLK  : out std_logic;
    DRAM_CKE  : out std_logic;
    DRAM_ADDR : out std_logic_vector(12 downto 0);
    DRAM_BA   : out std_logic_vector(1 downto 0);
    DRAM_CS_N, DRAM_CAS_N, DRAM_RAS_N, DRAM_WE_N : out std_logic;
    DRAM_DQ   : inout std_logic_vector(15 downto 0);
    DRAM_DQM  : out std_logic_vector(1 downto 0);

    -- Moteurs
    MTRL_N, MTRL_P : out std_logic;
    MTRR_N, MTRR_P : out std_logic;
    MTR_Sleep_n    : out std_logic;
    MTR_Fault_n    : in  std_logic;

    -- ADC
    LTC_ADC_CONVST : out std_logic;
    LTC_ADC_SCK    : out std_logic;
    LTC_ADC_SDI    : out std_logic;
    LTC_ADC_SDO    : in  std_logic;

    VCC3P3_PWRON_n : out std_logic
);
end robot;

architecture Structure of robot is

-- Déclaration Nios II
component nios_system is
port (
    clk_clk                              : in    std_logic;
    reset_reset_n                        : in    std_logic;
    leds_export                          : out   std_logic_vector(7 downto 0);
    switches_export                      : in    std_logic_vector(3 downto 0);
    sdram_wire_addr                      : out   std_logic_vector(12 downto 0);
    sdram_wire_ba                        : out   std_logic_vector(1 downto 0);
    sdram_wire_cas_n                     : out   std_logic;
    sdram_wire_cke                       : out   std_logic;
    sdram_wire_cs_n                      : out   std_logic;
    sdram_wire_dq                        : inout std_logic_vector(15 downto 0);
    sdram_wire_dqm                       : out   std_logic_vector(1 downto 0);
    sdram_wire_ras_n                     : out   std_logic;
    sdram_wire_we_n                      : out   std_logic;
    s_writedatar_export                  : out   std_logic_vector(13 downto 0);
    s_writedatal_export                  : out   std_logic_vector(13 downto 0);
    posdata0r_external_connection_export : in    std_logic_vector(7 downto 0);
    posdata1r_external_connection_export : in    std_logic_vector(7 downto 0);
    posdata2r_external_connection_export : in    std_logic_vector(7 downto 0)
);
end component;

component PWM_generation
port(
    clk, reset_n : in std_logic;
    s_writedataR, s_writedataL : in std_logic_vector(13 downto 0);
    dc_motor_p_R, dc_motor_n_R : out std_logic;
    dc_motor_p_L, dc_motor_n_L : out std_logic
);
end component;

component pll_2freqs
port(
    areset : in std_logic;
    inclk0 : in std_logic;
    c0 : out std_logic;
    c1 : out std_logic
);
end component;

component capteurs_sol
port(
    clk : in std_logic;
    reset_n : in std_logic;
    data_capture : in std_logic;
    data_readyr : out std_logic;
    data0r, data1r, data2r : out std_logic_vector(7 downto 0);
    data3r, data4r, data5r, data6r : out std_logic_vector(7 downto 0);
    ADC_CONVSTr : out std_logic;
    ADC_SCK : out std_logic;
    ADC_SDIr : out std_logic;
    ADC_SDO : in std_logic
);
end component;

-- Signals
signal rst_n : std_logic;
signal cmd_R : std_logic_vector(13 downto 0);
signal cmd_L : std_logic_vector(13 downto 0);
signal clk40 : std_logic;
signal clk2k : std_logic;
signal data_ready_s : std_logic;
signal pos_data0r_s : std_logic_vector(7 downto 0);
signal pos_data1r_s : std_logic_vector(7 downto 0);
signal pos_data2r_s : std_logic_vector(7 downto 0);
signal data3_s, data4_s, data5_s, data6_s : std_logic_vector(7 downto 0);

begin

-- Reset et activation moteurs
rst_n <= KEY(0);
MTR_Sleep_n <= '1';
VCC3P3_PWRON_n <= '0';

-- PLL
u_pll : entity work.pll_2freqs
port map(
    areset => not rst_n,
    inclk0 => CLOCK_50,
    c0 => clk40,
    c1 => clk2k
);

-- Capteurs sol
u_caps : entity work.capteurs_sol
port map(
    clk          => clk40,
    reset_n      => rst_n,
    data_capture => clk2k,
    data_readyr  => data_ready_s,
    data0r => pos_data0r_s,
    data1r => pos_data1r_s,
    data2r => pos_data2r_s,
    data3r => data3_s,
    data4r => data4_s,
    data5r => data5_s,
    data6r => data6_s,
    ADC_CONVSTr => LTC_ADC_CONVST,
    ADC_SCK     => LTC_ADC_SCK,
    ADC_SDIr    => LTC_ADC_SDI,
    ADC_SDO     => LTC_ADC_SDO
);

-- NIOS II
u0 : nios_system
port map(
    clk_clk                              => CLOCK_50,
    reset_reset_n                        => rst_n,
    leds_export                          => LED,
    switches_export                      => SW, -- étendre à 8 bits si nécessaire
    sdram_wire_addr                      => DRAM_ADDR,
    sdram_wire_ba                        => DRAM_BA,
    sdram_wire_cas_n                     => DRAM_CAS_N,
    sdram_wire_cke                       => DRAM_CKE,
    sdram_wire_cs_n                      => DRAM_CS_N,
    sdram_wire_dq                        => DRAM_DQ,
    sdram_wire_dqm                       => DRAM_DQM,
    sdram_wire_ras_n                     => DRAM_RAS_N,
    sdram_wire_we_n                      => DRAM_WE_N,
    s_writedatar_export                  => cmd_R,
    s_writedatal_export                  => cmd_L,
    posdata0r_external_connection_export => pos_data0r_s,
    posdata1r_external_connection_export => pos_data1r_s,
    posdata2r_external_connection_export => pos_data2r_s
);

-- PWM moteurs
PWM0 : entity work.PWM_generation
port map(
    clk => CLOCK_50,
    reset_n => rst_n,
    s_writedataR => cmd_R,
    s_writedataL => cmd_L,
    dc_motor_p_R => MTRR_P,
    dc_motor_n_R => MTRR_N,
    dc_motor_p_L => MTRL_P,
    dc_motor_n_L => MTRL_N
);

-- SDRAM clock
DRAM_CLK <= CLOCK_50;

end Structure;
